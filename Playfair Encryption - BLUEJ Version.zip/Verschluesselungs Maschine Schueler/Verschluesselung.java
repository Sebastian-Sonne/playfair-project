
/**
 * Klasse um eine Textnachricht (String) mit einem Passwort (String) zu ver- und entschluesseln (Ausgabe : String)
 * 
 * @author Sebastian Sonne
 * @version v4 | 04.12.23
 */
public class Verschluesselung
{
    /**
     * (leer) Konstruktor der Klasse Verschluesselung
     */
    public Verschluesselung()
    {

    }

    /**
     * ACHTUNG  METHODENKOPF auf KEINENFALL ABAENDERN
     * 
     * verschluesselt eine Textnachricht mit einem Passwort
     * 
     * @param eingabe   zu verschluesselnde Nachricht
     * @param password  password um die eingabe zu verschluesseln
     * @return          verschluesselte eingabe
     */
    public String encryption(String eingabe, String password) {
        
        return " "; // -> Gibt die verschluesselte Nachricht als String zurueck
    }

    /**
     * ACHTUNG  METHODENKOPF auf KEINENFALL ABAENDERN
     * 
     * entschluesselt eine Textnachricht mit einem Passwort
     * 
     * @param eingabe   zu entschluesselnde Nachricht
     * @param password  password um die eingabe zu entschluesseln
     * @return          entschluesselte eingabe
     */
    public String decryption(String eingabe, String password) {
        
        return " "; // -> Gibt die entschluesselte Nachricht als String zurueck
    }
}
