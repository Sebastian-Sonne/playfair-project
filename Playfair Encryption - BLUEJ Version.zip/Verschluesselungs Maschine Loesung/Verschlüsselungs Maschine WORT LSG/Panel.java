import javax.swing.*;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.util.HashSet;
import javafx.scene.layout.Border;

/**
 * Class to setup the panel on the frame of a graphical output
 * 
 * @author Sebastian Sonne
 * @version v3 | 11.07.23
 */
public class Panel extends JPanel implements ActionListener{
    //Frame
    final private static int HEIGHT = 450;
    final private static int WIDTH = 350;
    // UI IO
    JButton clear;
    JButton escape; 
    JButton encrypt;
    JButton decrypt;
    JTextArea inputField;
    JLabel inputLabel;
    JTextField passwordField;
    JLabel passwordLabel;
    JTextArea outputField;
    JLabel outputLabel;
    // Logic
    private char[] alphabet = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    HashSet<Character> set;
    Verschluesselung encryAlg;

    /**
     * constructor of Panel Class
     */
    public Panel() {
        //sets the look and feel of the java gui
        try {
            // Set System L&F
            UIManager.setLookAndFeel(
                UIManager.getSystemLookAndFeelClassName());
        } 
        catch (UnsupportedLookAndFeelException e) {
            JOptionPane.showMessageDialog(this, e, "Java L&F Exception Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, e, "Java L&F Exception Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (InstantiationException e) {
            JOptionPane.showMessageDialog(this, e, "Java L&F Exception Error", JOptionPane.ERROR_MESSAGE);
        }
        catch (IllegalAccessException e) {
            JOptionPane.showMessageDialog(this, e, "Java L&F Exception Error", JOptionPane.ERROR_MESSAGE);
        }

        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.setFocusable(true);

        //Buttons
        clear = new JButton();
        clear.addActionListener(this);
        escape = new JButton();
        escape.addActionListener(this);
        encrypt = new JButton();
        encrypt.addActionListener(this);
        decrypt = new JButton();
        decrypt.addActionListener(this);

        //Text Fields and Labels
        inputField = new JTextArea();
        inputLabel = new JLabel();
        passwordField = new JTextField();
        passwordLabel = new JLabel();
        outputField = new JTextArea();
        outputLabel = new JLabel();

        //Logic
        encryAlg = new Verschluesselung();
        //Hashset for Input Validation
        set = new HashSet<Character>();
        set.add(' ');
        for(int i=0; i<alphabet.length; i++) {
            set.add(alphabet[i]);
        }
    }

    /**
     * initalizes Java Paintcomponent
     * @param   g   java graphics
     */
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    /**
     * generates the Graphical UI
     * @param   g   java graphics
     */
    private void draw(Graphics g) {
        //clear Button
        clear.setBounds(245, 5, 80, 30);
        clear.setText("Clear");
        this.add(clear);

        //escape Button
        escape.setBounds(25, 5, 60, 30);
        escape.setText("Esc");
        this.add(escape);

        //encrypt Button
        encrypt.setBounds(25, 250, 140, 30);
        encrypt.setText("Verschlüsseln");
        this.add(encrypt);

        //decrypt Button
        decrypt.setBounds(185, 250, 140, 30);
        decrypt.setText("Entschlüsseln");
        this.add(decrypt);

        //input textfield
        inputField.setBounds(25, 65, 300, 100);
        inputField.setLineWrap(true);
        inputField.setWrapStyleWord(true);
        this.add(inputField);
        //input label
        inputLabel.setBounds(25, 45, 300, 20);
        inputLabel.setText("Eingabe:");
        this.add(inputLabel);

        //password textfield
        passwordField.setBounds(25, 195, 300, 30);
        passwordField.addKeyListener(new KeyAdapter() {
                public void keyTyped(KeyEvent e) {
                    if (passwordField.getText().length() >= 50) {
                        e.consume();
                    }
                }
            });
        passwordField.setBorder(null);
        this.add(passwordField);
        //password label
        passwordLabel.setBounds(25, 175, 300, 20);
        passwordLabel.setText("Password:");
        this.add(passwordLabel);

        //output textField
        outputField.setBounds(25, 325, 300, 100);
        outputField.setLineWrap(true);
        outputField.setWrapStyleWord(true);
        this.add(outputField);
        //output label
        outputLabel.setBounds(25, 305, 300, 20);
        outputLabel.setText("Ausgabe:");
        this.add(outputLabel);

        //copyright String
        g.setFont(new Font("Calibri", Font.PLAIN, 15));
        g.drawString("©Sebastian Sonne | 2023", 3, 445);
    }

    /**
     * test method
     */
    private static String substring(String string, int beginIndex, int length) {
        int endIndex = beginIndex + length;
        return string.substring(beginIndex, endIndex);
    }

    /**
     * Overrides the actionPerformed method of the ActionListener Class
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        //error messages
        String e1 = "Input Field empty\nPlease enter an input";
        String e2 = "Password Field empty\nPlease enter a password";
        String e3 = "Invalid Input\nOnly use standard English letters, without 'j'";
        String e4 = "Invalid password\nOnly use standard English letters, without 'j'or blank";
        String f1 = "";

        if(e.getSource() == encrypt) {

            switch(checkInput(inputField.getText().toUpperCase(), passwordField.getText().toUpperCase())) {
                case "e0":
                    outputField.setText(encryAlg.encryption(inputField.getText(), passwordField.getText()));
                    break;
                case "e1": 
                    JOptionPane.showMessageDialog(this, e1, "Input Validation Error", JOptionPane.ERROR_MESSAGE);
                    break;
                case "e2": 
                    JOptionPane.showMessageDialog(this, e2, "Input Validation Error", JOptionPane.ERROR_MESSAGE);
                    break;
                case "e3": 
                    JOptionPane.showMessageDialog(this, e3, "Input Validation Error", JOptionPane.ERROR_MESSAGE);
                    break;
                case "e4": 
                    JOptionPane.showMessageDialog(this, e4, "Input Validation Error", JOptionPane.ERROR_MESSAGE);
                    break;
            }
        }

        if(e.getSource() == decrypt) {

            switch(checkInput(inputField.getText().toUpperCase(), passwordField.getText().toUpperCase())) {
                case "e0": 
                    outputField.setText(encryAlg.decryption(inputField.getText(), passwordField.getText()));
                    break;
                case "e1": 
                    JOptionPane.showMessageDialog(this, e1, "Input Validation Error", JOptionPane.ERROR_MESSAGE);
                    break;
                case "e2": 
                    JOptionPane.showMessageDialog(this, e2, "Input Validation Error", JOptionPane.ERROR_MESSAGE);
                    break;
                case "e3": 
                    JOptionPane.showMessageDialog(this, e3, "Input Validation Error", JOptionPane.ERROR_MESSAGE);
                    break;
                case "e4": 
                    JOptionPane.showMessageDialog(this, e4, "Input Validation Error", JOptionPane.ERROR_MESSAGE);
                    break;
            }
        }

        if(e.getSource() == escape) {
            System.exit(0);
        }

        if(e.getSource() == clear) {
            inputField.setText("");
            passwordField.setText("");
            outputField.setText("");
        }
    }

    /**
     * checks whether a String is ok to use
     * @param   s   input String
     * @return  returns the according error type
     */
    public String checkInput(String s, String pw) {
        if(s.isEmpty() == true) {
            return "e1";
        }
        if(passwordField.getText().isEmpty() == true) {
            return "e2";
        }
        for(int i=0; i<s.length(); i++) {
            if(set.contains(s.charAt(i)) == false) {
                return "e3";
            }
        }
        for(int i=0; i<pw.length(); i++) {
            if(set.contains(pw.charAt(i)) == false) {
                return "e4";
            }
        }
        return "e0";
    }
}
