
/**
 * Klasse um eine Textnachricht (String) mit einem Passwort (String) zu ver- und entschluesseln (Ausgabe : String)
 * 
 * @author Sebastian Sonne, Alexander Frank
 * @version v1 | 27.06.23
 */
public class Verschluesselung
{
    private char[] alphabet = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    private String matrix;      // Verschluesselungsmatrix (in Form eines Strings)

    /**
     * Konstruktor der Klasse Verschluesselung
     */
    public Verschluesselung()
    {

    }

    /**
     * ACHTUNG  METHODENKOPF auf KEINENFALL ABAENDERN
     * 
     * verschluesselt eine Textnachricht mit einem Passwort
     * @param eingabe   zu verschluesselnde Nachricht
     * @param password  password um die eingabe zu verschluesseln
     * @return          verschluesselter eingabe
     */
    public String encryption(String eingabe, String password) {
        matrix = matrixErzeugen(schluesselBereinigen(password.toUpperCase())); // Erzeugt String Matrix mit dem Schluessel
        
        return verschluesseln(klartextZerlegen(eingabe.toUpperCase())); // Gibt die verschluesselte Nachricht als String zurueck
    }

    /**
     * ACHTUNG  METHODENKOPF auf KEINENFALL ABAENDERN
     * 
     * entschluesselt eine Textnachricht mit einem Passwort
     * @param eingabe   zu entschluesselnde Nachricht
     * @param password  password um die eingabe zu entschluesseln
     * @return          entschluesselter eingabe
     */
    public String decryption(String eingabe, String password) {
        matrix = matrixErzeugen(schluesselBereinigen(password.toUpperCase())); // Erzeugt String Matrix mit dem Schluessel
        
        return entschluesseltesReinigen(entschluesseln(klartextZerlegen(eingabe.toUpperCase()))); // Gibt die entschluesselte Nachricht als String zurueck
    }

    /**
     * Entfernt saemtliche Buchstaben aus dem Schluesselwort,
     * die mehr als nur einmal vorkommen.
     * 
     * @param s     Zu bereinigendes Schluesselwort
     * @return      Bereinigtes Schluesselwort
     */
    private String schluesselBereinigen(String s)
    {
        String ergebnis = "";

        for (int i = 0; i < s.length(); i++)
        {
            String temp = "" + s.charAt(i); // s.charAt(i) liefert ein char zurueck, deshalb "" + ... am Anfang, damit ein String herauskommt

            if (!ergebnis.contains(temp))
            {
                ergebnis = ergebnis + temp;
            }
        }

        return ergebnis;
    }

    /**
     * Zerlegt den Klartext in Zweierbloecke und fuellt, wo noetig,
     * mit "X" auf.
     * 
     * @param text      Der zu zerlegende Text als String
     * @return          Der zerlegte Text
     */
    private String klartextZerlegen(String text)
    {

        for (int i = 0; i < text.length() - 1; i++)
        {
            if (text.charAt(i + 1) == text.charAt(i) && (i + 1) % 2 == 1)
            {
                text = text.substring(0, i + 1) + "X" + text.substring(i + 1);
            }
        }

        if (text.length() % 2 == 1)
        {
            text = text + "X";
        }

        return text;
    }

    /**
     * Erstellt eine Matrix in Form eines Strings.
     * 
     * @param s     Schluesselwort, das der Matrix zugrunde liegt
     * @return      Matrix als String
     */
    private String matrixErzeugen(String s)
    {
        String matrix = s;

        for (int i = 0; i < alphabet.length; i++)
        {
            String temp = "" + alphabet[i];

            if (!matrix.contains(temp))
            {
                matrix = matrix + temp;
            }
        }

        return matrix;
    }
    
     /**
     * Bereinigt das entschluesselte Wort um die unnoetigen "X".
     * 
     * @param s     Das zu bereinigende Wort
     */
    private String entschluesseltesReinigen(String s)
    {
        for (int i = 0; i < s.length(); i++)
        {
            if (s.charAt(i) == 'X')
            {
                s = s.substring(0, i) + s.substring(i + 1);
            }
        }
        
        return s;
    }

    /**
     * Verschluesselt ein beliebiges Wort. Achtung: Vorher muss
     * das Schluesselwort gesetzt und die Verschluesselungsmatrix
     * erstellt sein!
     * 
     * @param s     Das zu verschluesselnde Wort
     * @return      Verschluesseltes Wort
     */
    private String verschluesseln(String s)
    {
        String ergebnis = "";

        for (int i = 0; i < s.length(); i = i + 2)              // Einlesen der Wortes in 2-Buchstaben-Schritten
        {
            int zeile1  = matrix.indexOf(s.charAt(i)) / 5;      // Zeilenkoordinate in der Matrix (erster Buchstabe)
            int spalte1 = matrix.indexOf(s.charAt(i)) % 5;      // Spaltenkoordinate in der Matrix (erster Buchstabe)
            int zeile2  = matrix.indexOf(s.charAt(i + 1)) / 5;  // Zeilenkoordinate in der Matrix (zweiter Buchstabe)
            int spalte2 = matrix.indexOf(s.charAt(i + 1)) % 5;  // Spaltenkoordinate in der Matrix (zweiter Buchstabe)

            if (zeile1 == zeile2)   // Fall 1 beim Verschluesseln (s. Arbeitsblatt)
            {
                spalte1 = (spalte1 + 1) % 5;
                spalte2 = (spalte2 + 1) % 5;
            }
            else if (spalte1 == spalte2)    // Fall 2 beim Verschluesseln (s. Arbeitsblatt)
            {
                zeile1 = (zeile1 + 1) % 5;
                zeile2 = (zeile2 + 1) % 5;
            }
            else    // Fall 3 beim Verschluesseln (s. Arbeitsblatt)
            {
                int temp = spalte1;
                spalte1 = spalte2;
                spalte2 = temp;
            }

            char c1 = matrix.charAt(zeile1 * 5 + spalte1);
            char c2 = matrix.charAt(zeile2 * 5 + spalte2);

            ergebnis = ergebnis + c1 + c2;
            // ergebnis = ergebnis.concat("" + c1).concat("" + c2);
        }

        return ergebnis;
    }

    /**
     * Entschluesselt ein beliebiges Wort. Achtung: Vorher muss
     * das Schluesselwort gesetzt und die Verschluesselungsmatrix
     * erstellt sein!
     * 
     * @param s     Das zu entschluesselnde Wort
     * @return      Entschluesseltes, jedoch nicht bereinigtes Wort
     */
    private String entschluesseln(String s)
    {
        String ergebnis = "";

        for (int i = 0; i < s.length(); i = i + 2)
        {
            int zeile1  = matrix.indexOf(s.charAt(i)) / 5;
            int spalte1 = matrix.indexOf(s.charAt(i)) % 5;
            int zeile2  = matrix.indexOf(s.charAt(i + 1)) / 5;
            int spalte2 = matrix.indexOf(s.charAt(i + 1)) % 5; 

            if (zeile1 == zeile2)
            {
                spalte1 = (spalte1 + 4) % 5;
                spalte2 = (spalte2 + 4) % 5;
            }
            else if (spalte1 == spalte2)
            {
                zeile1 = (zeile1 + 4) % 5;
                zeile2 = (zeile2 + 4) % 5;
            }
            else
            {
                int temp = spalte1;
                spalte1 = spalte2;
                spalte2 = temp;
            }

            char c1 = matrix.charAt(zeile1 * 5 + spalte1);
            char c2 = matrix.charAt(zeile2 * 5 + spalte2);

            ergebnis = ergebnis + c1 + c2;
        }

        return ergebnis;
    }
}
